/* ============================================================
   UNGUBANI — Contactos / Contact
   Formspree integration — replace FORMSPREE_ENDPOINT with your
   real Formspree form ID when ready, e.g.:
     https://formspree.io/f/YOUR_FORM_ID
   Steps:
     1. Go to https://formspree.io and create a free account
     2. Create a new form and copy the endpoint URL
     3. Replace the FORMSPREE_ENDPOINT constant below
   ============================================================ */
import { useEffect, useState } from "react";
import { MapPin, Phone, Mail, Clock, Send, ArrowRight, Loader2, CheckCircle2, AlertCircle } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useLanguage } from "@/contexts/LanguageContext";
import { useTransitionNavigate } from "@/components/PageTransition";

/* ── 🔧 REPLACE THIS with your Formspree endpoint ─────────────────────────
   Example: "https://formspree.io/f/xpwzgkla"
   Until replaced, the form will show a clear placeholder warning.          */
const FORMSPREE_ENDPOINT = "https://formspree.io/f/YOUR_FORM_ID";

const IS_PLACEHOLDER = FORMSPREE_ENDPOINT.includes("YOUR_FORM_ID");

function useFadeUp() {
  useEffect(() => {
    const els = document.querySelectorAll(".fade-up");
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.1 });
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);
}

type FormState = "idle" | "submitting" | "success" | "error";

export default function Contactos() {
  useFadeUp();
  const { t } = useLanguage();
  const navigate = useTransitionNavigate();
  const [form, setForm] = useState({ nome: "", email: "", telefone: "", assunto: "", mensagem: "" });
  const [formState, setFormState] = useState<FormState>("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormState("submitting");
    setErrorMsg("");

    if (IS_PLACEHOLDER) {
      // Simulate a short delay to show the loading state, then show placeholder message
      await new Promise((r) => setTimeout(r, 800));
      setFormState("error");
      setErrorMsg(
        "⚠️ Formspree ainda não está configurado. Substitua FORMSPREE_ENDPOINT em Contactos.tsx pelo URL do seu formulário Formspree."
      );
      return;
    }

    try {
      const res = await fetch(FORMSPREE_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({
          name: form.nome,
          email: form.email,
          phone: form.telefone,
          subject: form.assunto,
          message: form.mensagem,
        }),
      });

      if (res.ok) {
        setFormState("success");
        setForm({ nome: "", email: "", telefone: "", assunto: "", mensagem: "" });
      } else {
        const data = await res.json().catch(() => ({}));
        setErrorMsg(data?.errors?.[0]?.message ?? t("contact.form.error"));
        setFormState("error");
      }
    } catch {
      setErrorMsg(t("contact.form.error"));
      setFormState("error");
    }
  };

  const go = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => { e.preventDefault(); navigate(href); };

  const inputStyle = {
    borderColor: "var(--card-border)",
    background: "var(--card-bg)",
    color: "var(--text-heading)",
  };

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-36 pb-20" style={{ background: "oklch(0.22 0.06 255)" }}>
        <div className="container">
          <div className="section-label section-label--light">{t("contact.tag")}</div>
          <h1 className="text-white mb-4" style={{ fontSize: "clamp(2.5rem, 5vw, 4rem)" }}>{t("contact.h1")}</h1>
          <div className="divider divider--sky mb-6" />
          <p className="text-white/60 max-w-xl leading-relaxed">{t("contact.sub")}</p>
        </div>
      </section>

      {/* Contact grid */}
      <section className="section-light py-24">
        <div className="container">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Info */}
            <div className="fade-up">
              <h3 className="text-head-adaptive mb-6" style={{ fontSize: "1.4rem" }}>{t("contact.info.h3")}</h3>
              <div className="space-y-5">
                {[
                  { icon: <MapPin size={16} />, labelKey: "contact.address", valueNode: <p className="text-body-adaptive text-sm leading-relaxed">{t("contact.address.val")}</p> },
                  { icon: <Phone size={16} />, labelKey: "contact.phone", valueNode: <a href="tel:+351000000000" className="text-body-adaptive text-sm hover:text-blue-600 transition-colors">{t("contact.phone.val")}</a> },
                  { icon: <Mail size={16} />, labelKey: "contact.email", valueNode: <a href="mailto:geral@ungubani.pt" className="text-body-adaptive text-sm hover:text-blue-600 transition-colors">geral@ungubani.pt</a> },
                  { icon: <Clock size={16} />, labelKey: "contact.hours", valueNode: <p className="text-body-adaptive text-sm leading-relaxed">{t("contact.hours.val")}<br />{t("contact.hours.val2")}</p> },
                ].map((item) => (
                  <div key={item.labelKey} className="flex gap-3 items-start">
                    <div className="w-9 h-9 rounded flex items-center justify-center flex-shrink-0 text-white"
                      style={{ background: "oklch(0.22 0.06 255)" }}>
                      {item.icon}
                    </div>
                    <div>
                      <div className="text-[0.68rem] font-bold tracking-widest uppercase text-muted-adaptive mb-0.5">{t(item.labelKey)}</div>
                      {item.valueNode}
                    </div>
                  </div>
                ))}
              </div>

              {/* Formspree setup notice — hidden in production, shown only in dev */}
              {IS_PLACEHOLDER && process.env.NODE_ENV === 'development' && (
                <div className="mt-8 p-4 rounded-sm border border-amber-400/40 bg-amber-50/60 dark:bg-amber-900/20">
                  <p className="text-[0.72rem] font-semibold text-amber-700 dark:text-amber-400 leading-relaxed">
                    <strong>🔧 Para ativar o envio de emails:</strong><br />
                    1. Crie uma conta em <a href="https://formspree.io" target="_blank" rel="noopener noreferrer" className="underline">formspree.io</a><br />
                    2. Crie um novo formulário e copie o URL<br />
                    3. Substitua <code className="bg-amber-100 dark:bg-amber-900/40 px-1 rounded">FORMSPREE_ENDPOINT</code> em <code className="bg-amber-100 dark:bg-amber-900/40 px-1 rounded">Contactos.tsx</code>
                  </p>
                </div>
              )}

              <div className="mt-6 p-5 rounded-sm" style={{ background: "oklch(0.22 0.06 255 / 0.06)", borderLeft: "3px solid oklch(0.50 0.14 255)" }}>
                <h5 className="text-head-adaptive font-bold mb-2 text-sm">{t("contact.prime.title")}</h5>
                <p className="text-muted-adaptive text-xs leading-relaxed mb-3">{t("contact.prime.desc")}</p>
                <a href="/prime-infinity" onClick={(e) => go(e, "/prime-infinity")}
                  className="inline-flex items-center gap-1.5 text-[0.72rem] font-bold tracking-wider uppercase transition-colors duration-200"
                  style={{ color: "oklch(0.50 0.14 255)" }}>
                  {t("contact.prime.cta")} <ArrowRight size={12} />
                </a>
              </div>
            </div>

            {/* Form */}
            <div className="lg:col-span-2 fade-up">
              {formState === "success" ? (
                <div className="flex flex-col items-center justify-center h-full min-h-[400px] text-center p-10 rounded-sm card-adaptive border">
                  <div className="w-16 h-16 rounded-full flex items-center justify-center mb-6"
                    style={{ background: "oklch(0.50 0.14 255 / 0.1)" }}>
                    <CheckCircle2 size={28} style={{ color: "oklch(0.50 0.14 255)" }} />
                  </div>
                  <h3 className="text-head-adaptive mb-2" style={{ fontSize: "1.5rem" }}>{t("contact.form.success")}</h3>
                  <p className="text-muted-adaptive text-sm mt-2">{t("contact.form.success.sub")}</p>
                  <button
                    onClick={() => setFormState("idle")}
                    className="mt-6 text-sm font-semibold underline text-muted-adaptive hover:text-blue-600 transition-colors">
                    {t("contact.form.new")}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-[0.68rem] font-bold tracking-widest uppercase text-muted-adaptive mb-1.5">{t("contact.form.name")}</label>
                      <input required name="nome" value={form.nome} onChange={handleChange}
                        className="w-full px-4 py-3 text-sm border rounded-sm focus:outline-none focus:ring-2 transition-all"
                        style={inputStyle} />
                    </div>
                    <div>
                      <label className="block text-[0.68rem] font-bold tracking-widest uppercase text-muted-adaptive mb-1.5">{t("contact.form.email")}</label>
                      <input required type="email" name="email" value={form.email} onChange={handleChange}
                        className="w-full px-4 py-3 text-sm border rounded-sm focus:outline-none focus:ring-2 transition-all"
                        style={inputStyle} />
                    </div>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-[0.68rem] font-bold tracking-widest uppercase text-muted-adaptive mb-1.5">{t("contact.form.phone")}</label>
                      <input name="telefone" value={form.telefone} onChange={handleChange}
                        className="w-full px-4 py-3 text-sm border rounded-sm focus:outline-none focus:ring-2 transition-all"
                        style={inputStyle} placeholder="+351 000 000 000" />
                    </div>
                    <div>
                      <label className="block text-[0.68rem] font-bold tracking-widest uppercase text-muted-adaptive mb-1.5">{t("contact.form.subject")}</label>
                      <select required name="assunto" value={form.assunto} onChange={handleChange}
                        className="w-full px-4 py-3 text-sm border rounded-sm focus:outline-none focus:ring-2 transition-all"
                        style={inputStyle}>
                        <option value="">{t("contact.form.subject.select")}</option>
                        <option value="budget">{t("contact.form.subject.budget")}</option>
                        <option value="prime">{t("contact.form.subject.prime")}</option>
                        <option value="info">{t("contact.form.subject.info")}</option>
                        <option value="other">{t("contact.form.subject.other")}</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[0.68rem] font-bold tracking-widest uppercase text-muted-adaptive mb-1.5">{t("contact.form.msg")}</label>
                    <textarea required name="mensagem" value={form.mensagem} onChange={handleChange} rows={6}
                      className="w-full px-4 py-3 text-sm border rounded-sm focus:outline-none focus:ring-2 transition-all resize-none"
                      style={inputStyle}
                      placeholder={t("contact.form.msg.placeholder")} />
                  </div>

                  {/* Error message */}
                  {formState === "error" && (
                    <div className="flex items-start gap-2 p-3 rounded-sm bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800">
                      <AlertCircle size={16} className="text-red-500 flex-shrink-0 mt-0.5" />
                      <p className="text-red-600 dark:text-red-400 text-xs leading-relaxed">{errorMsg || t("contact.form.error")}</p>
                    </div>
                  )}

                  <button type="submit" disabled={formState === "submitting"}
                    className="btn-press inline-flex items-center gap-2 px-8 py-3.5 text-white font-bold text-sm tracking-widest uppercase rounded transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg disabled:opacity-60 disabled:cursor-not-allowed disabled:hover:translate-y-0"
                    style={{ background: "oklch(0.22 0.06 255)" }}>
                    {formState === "submitting" ? (
                      <><Loader2 size={14} className="animate-spin" /> {t("contact.form.sending")}</>
                    ) : (
                      <>{t("contact.form.submit")} <Send size={14} /></>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Map placeholder */}
      <section className="section-alt">
        <div className="container py-12">
          <div className="card-adaptive rounded-sm overflow-hidden border" style={{ height: "320px" }}>
            <div className="w-full h-full flex flex-col items-center justify-center gap-3">
              <MapPin size={32} style={{ color: "oklch(0.50 0.14 255)" }} />
              <p className="text-muted-adaptive text-sm font-medium">{t("contact.address.val")}</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
