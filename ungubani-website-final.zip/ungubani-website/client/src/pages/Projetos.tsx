/* ============================================================
   UNGUBANI — Projetos / Projects
   Fully translated via LanguageContext (PT/EN)
   ============================================================ */
import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useLanguage } from "@/contexts/LanguageContext";

function useFadeUp() {
  useEffect(() => {
    const els = document.querySelectorAll(".fade-up");
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.1 });
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);
}

/* Category keys used as stable identifiers for filtering */
type CatKey = "all" | "residential" | "commercial" | "public" | "rehab" | "ongoing";

const projectData = [
  { img: "/manus-storage/project-residential_34c0ac3f.jpg", cat: "residential" as CatKey, titleKey: "proj.p1.title", locKey: "proj.p1.loc", descKey: "proj.p1.desc" },
  { img: "/manus-storage/project-commercial_610e6bc4.jpg",  cat: "commercial"  as CatKey, titleKey: "proj.p2.title", locKey: "proj.p2.loc", descKey: "proj.p2.desc" },
  { img: "/manus-storage/about-construction_832472cf.jpg",  cat: "public"      as CatKey, titleKey: "proj.p3.title", locKey: "proj.p3.loc", descKey: "proj.p3.desc" },
  { img: "/manus-storage/project-residential_34c0ac3f.jpg", cat: "residential" as CatKey, titleKey: "proj.p4.title", locKey: "proj.p4.loc", descKey: "proj.p4.desc" },
  { img: "/manus-storage/about-construction_832472cf.jpg",  cat: "rehab"       as CatKey, titleKey: "proj.p5.title", locKey: "proj.p5.loc", descKey: "proj.p5.desc" },
  { img: "/manus-storage/project-commercial_610e6bc4.jpg",  cat: "public"      as CatKey, titleKey: "proj.p6.title", locKey: "proj.p6.loc", descKey: "proj.p6.desc" },
  { img: "/manus-storage/prime-infinity_fbdb134d.jpg",      cat: "ongoing"     as CatKey, titleKey: "proj.p9.title", locKey: "proj.p9.loc", descKey: "proj.p9.desc" },
  { img: "/manus-storage/project-residential_34c0ac3f.jpg", cat: "residential" as CatKey, titleKey: "proj.p7.title", locKey: "proj.p7.loc", descKey: "proj.p7.desc" },
  { img: "/manus-storage/project-commercial_610e6bc4.jpg",  cat: "commercial"  as CatKey, titleKey: "proj.p8.title", locKey: "proj.p8.loc", descKey: "proj.p8.desc" },
];

const filterKeys: { key: CatKey; labelKey: string }[] = [
  { key: "all",         labelKey: "proj.filter.all" },
  { key: "residential", labelKey: "proj.filter.residential" },
  { key: "commercial",  labelKey: "proj.filter.commercial" },
  { key: "public",      labelKey: "proj.filter.public" },
  { key: "rehab",       labelKey: "proj.filter.rehab" },
  { key: "ongoing",     labelKey: "proj.filter.ongoing" },
];

const catLabelKey: Record<CatKey, string> = {
  all: "proj.filter.all",
  residential: "proj.filter.residential",
  commercial: "proj.filter.commercial",
  public: "proj.filter.public",
  rehab: "proj.filter.rehab",
  ongoing: "proj.filter.ongoing",
};

export default function Projetos() {
  useFadeUp();
  const { t } = useLanguage();
  const [active, setActive] = useState<CatKey>("all");
  const filtered = active === "all" ? projectData : projectData.filter((p) => p.cat === active);

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-36 pb-20" style={{ background: "oklch(0.22 0.06 255)" }}>
        <div className="container">
          <div className="section-label section-label--light">{t("proj.tag")}</div>
          <h1 className="text-white mb-4" style={{ fontSize: "clamp(2.5rem, 5vw, 4rem)" }}>{t("proj.h1")}</h1>
          <div className="divider divider--sky mb-6" />
          <p className="text-white/60 max-w-xl leading-relaxed">{t("proj.sub")}</p>
        </div>
      </section>

      {/* Filters + Grid */}
      <section className="section-light py-16">
        <div className="container">
          {/* Filter tabs */}
          <div className="flex flex-wrap gap-2 mb-12">
            {filterKeys.map(({ key, labelKey }) => (
              <button
                key={key}
                onClick={() => setActive(key)}
                className="px-4 py-2 text-[0.72rem] font-bold tracking-widest uppercase rounded transition-all duration-200"
                style={{
                  background: active === key ? "oklch(0.22 0.06 255)" : "var(--card-bg)",
                  color: active === key ? "white" : "var(--text-body)",
                  border: `1px solid ${active === key ? "oklch(0.22 0.06 255)" : "var(--card-border)"}`,
                }}
              >
                {t(labelKey)}
              </button>
            ))}
          </div>

          {/* Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((p, i) => (
              <div key={i} className="fade-up group relative overflow-hidden rounded-sm cursor-pointer" style={{ height: "360px" }}>
                <img src={p.img} alt={t(p.titleKey)} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <div className="absolute inset-0 transition-opacity duration-300"
                  style={{ background: "linear-gradient(to top, oklch(0.12 0.05 255 / 0.92) 0%, oklch(0.12 0.05 255 / 0.2) 60%, transparent 100%)" }} />
                <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                  <span className="inline-block text-[0.62rem] font-bold tracking-widest uppercase px-2.5 py-1 rounded mb-3"
                    style={{ background: "oklch(0.50 0.14 255)", color: "white" }}>
                    {t(catLabelKey[p.cat])}
                  </span>
                  <h4 className="text-white font-bold text-base mb-1">{t(p.titleKey)}</h4>
                  <p className="text-white/50 text-xs tracking-wider mb-2">{t(p.locKey)}</p>
                  <p className="text-white/70 text-xs leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-300">{t(p.descKey)}</p>
                </div>
              </div>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-20 text-muted-adaptive">{t("proj.empty")}</div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
