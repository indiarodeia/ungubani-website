/* ============================================================
   UNGUBANI — Quem Somos / About Us
   Fully translated via LanguageContext (PT/EN)
   ============================================================ */
import { useEffect } from "react";
import { ArrowRight, Award, CheckCircle } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useTransitionNavigate } from "@/components/PageTransition";
import { useLanguage } from "@/contexts/LanguageContext";

function useFadeUp() {
  useEffect(() => {
    const els = document.querySelectorAll(".fade-up");
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.1 });
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);
}

export default function QuemSomos() {
  useFadeUp();
  const navigate = useTransitionNavigate();
  const { t } = useLanguage();
  const go = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => { e.preventDefault(); navigate(href); };

  const services = [1, 2, 3, 4, 5, 6].map((i) => ({
    title: t(`svc.${i}.title`),
    desc: t(`svc.${i}.desc`),
  }));

  const steps = [
    { n: "01", titleKey: "about.step1.title", descKey: "about.step1.desc" },
    { n: "02", titleKey: "about.step2.title", descKey: "about.step2.desc" },
    { n: "03", titleKey: "about.step3.title", descKey: "about.step3.desc" },
    { n: "04", titleKey: "about.step4.title", descKey: "about.step4.desc" },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-36 pb-20 overflow-hidden" style={{ background: "oklch(0.22 0.06 255)" }}>
        <div className="absolute inset-0 opacity-10">
          <img src="/manus-storage/about-construction_832472cf.jpg" alt="" className="w-full h-full object-cover" />
        </div>
        <div className="container relative z-10">
          <div className="section-label section-label--light">{t("about.tag")}</div>
          <h1 className="text-white mb-4" style={{ fontSize: "clamp(2.5rem, 5vw, 4rem)" }}>
            {t("about.h1")}
          </h1>
          <div className="divider divider--sky mb-6" />
          <p className="text-white/60 max-w-xl leading-relaxed">{t("about.sub")}</p>
        </div>
      </section>

      {/* About */}
      <section className="section-light py-24">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="fade-up">
              <div className="section-label">{t("about.history.tag")}</div>
              <h2 className="text-head-adaptive mb-5" style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}>
                {t("about.history.h2")}
              </h2>
              <div className="divider mb-6" />
              <p className="text-body-adaptive mb-5 leading-relaxed">{t("about.history.p1")}</p>
              <p className="text-body-adaptive mb-5 leading-relaxed">{t("about.history.p2")}</p>
              <p className="text-body-adaptive mb-8 leading-relaxed">{t("about.history.p3")}</p>
              <div className="flex items-start gap-3 p-4 rounded-sm" style={{ background: "oklch(0.22 0.06 255 / 0.06)", borderLeft: "3px solid oklch(0.50 0.14 255)" }}>
                <Award size={20} className="flex-shrink-0 mt-0.5" style={{ color: "oklch(0.50 0.14 255)" }} />
                <p className="text-body-adaptive text-sm leading-relaxed">
                  <strong>{t("about.alvara.label")}</strong> — {t("about.alvara.desc")}
                </p>
              </div>
            </div>
            <div className="relative fade-up">
              <img src="/manus-storage/about-construction_832472cf.jpg" alt="Equipa Ungubani" className="w-full h-[460px] object-cover rounded-sm" />
              <div className="absolute -bottom-5 -left-5 p-5 rounded-sm hidden lg:block"
                style={{ background: "oklch(0.22 0.06 255)" }}>
                <div className="text-white font-black text-2xl" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>{t("about.alvara.label").split(" ")[0]}</div>
                <div className="text-white font-black text-4xl" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>{t("about.alvara.label").split(" ").slice(1).join(" ")}</div>
                <div className="text-white/50 text-[0.65rem] tracking-widest uppercase mt-1">Construção Civil</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="section-alt py-24">
        <div className="container">
          <div className="text-center mb-14 fade-up">
            <div className="section-label" style={{ justifyContent: "center" }}>{t("about.services.tag")}</div>
            <h2 className="text-head-adaptive" style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}>{t("about.services.h2")}</h2>
            <div className="divider divider--center mt-4" />
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {services.map((s, i) => (
              <div key={i} className="card-adaptive fade-up p-6 rounded-sm border hover:shadow-md hover:-translate-y-0.5 transition-all duration-300">
                <CheckCircle size={18} className="mb-3 transition-transform duration-300 hover:scale-110" style={{ color: "oklch(0.50 0.14 255)" }} />
                <h4 className="text-head-adaptive font-bold mb-2 text-sm">{s.title}</h4>
                <p className="text-muted-adaptive text-sm leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-24" style={{ background: "oklch(0.22 0.06 255)" }}>
        <div className="container">
          <div className="text-center mb-14 fade-up">
            <div className="section-label section-label--light" style={{ justifyContent: "center" }}>{t("about.process.tag")}</div>
            <h2 className="text-white" style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}>{t("about.process.h2")}</h2>
            <div className="divider divider--sky divider--center mt-4" />
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((s, i) => (
              <div key={i} className="fade-up relative">
                {i < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-full w-full h-px z-0" style={{ background: "oklch(1 0 0 / 0.1)" }} />
                )}
                <div className="relative z-10 hover:-translate-y-1 transition-transform duration-300">
                  <div className="font-black text-5xl mb-4" style={{ fontFamily: "'Barlow Condensed', sans-serif", color: "oklch(0.50 0.14 255 / 0.4)" }}>{s.n}</div>
                  <h4 className="text-white font-bold mb-2">{t(s.titleKey)}</h4>
                  <p className="text-white/50 text-sm leading-relaxed">{t(s.descKey)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-light py-20">
        <div className="container text-center fade-up">
          <h2 className="text-head-adaptive mb-4" style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}>
            {t("about.cta.h2")}
          </h2>
          <p className="text-muted-adaptive mb-8 max-w-md mx-auto text-sm">{t("about.cta.sub")}</p>
          <a href="/contactos" onClick={(e) => go(e, "/contactos")}
            className="btn-solid btn-press inline-flex items-center gap-2 px-8 py-4 text-white font-bold text-sm tracking-widest uppercase rounded"
            style={{ background: "oklch(0.22 0.06 255)" }}>
            {t("about.cta.btn")} <ArrowRight size={15} />
          </a>
        </div>
      </section>

      <Footer />
    </div>
  );
}
