/* ============================================================
   UNGUBANI — Homepage  |  Design: "Monolithic Authority"
   Fully translated via LanguageContext (PT/EN)
   ============================================================ */
import { useEffect, useRef, useState } from "react";
import { ArrowRight, ChevronDown, Award, Building2, Wrench, Shield, LayoutGrid, HardHat, Layers } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useTransitionNavigate } from "@/components/PageTransition";
import { useLanguage } from "@/contexts/LanguageContext";

function Counter({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting && !started.current) {
        started.current = true;
        const dur = 1800;
        const start = performance.now();
        const tick = (now: number) => {
          const p = Math.min((now - start) / dur, 1);
          const ease = 1 - Math.pow(1 - p, 3);
          setVal(Math.round(ease * target));
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      }
    }, { threshold: 0.4 });
    obs.observe(el);
    return () => obs.disconnect();
  }, [target]);
  return <span ref={ref}>{val}{suffix}</span>;
}

function useFadeUp() {
  useEffect(() => {
    const els = document.querySelectorAll(".fade-up");
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.12 });
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);
}

const serviceIcons = [
  <Building2 size={22} />, <Layers size={22} />, <LayoutGrid size={22} />,
  <Shield size={22} />, <HardHat size={22} />, <Wrench size={22} />,
];

const valueEmojis = ["⚖️", "🤝", "🏆", "💡"];

const projects = [
  { img: "/manus-storage/project-residential_34c0ac3f.jpg", catKey: "proj.filter.residential", titleKey: "proj.p1.title", locKey: "proj.p1.loc", descKey: "proj.p1.desc" },
  { img: "/manus-storage/project-commercial_610e6bc4.jpg", catKey: "proj.filter.commercial", titleKey: "proj.p2.title", locKey: "proj.p2.loc", descKey: "proj.p2.desc" },
  { img: "/manus-storage/about-construction_832472cf.jpg", catKey: "proj.filter.public", titleKey: "proj.p3.title", locKey: "proj.p3.loc", descKey: "proj.p3.desc" },
];

export default function Home() {
  useFadeUp();
  const navigate = useTransitionNavigate();
  const { t } = useLanguage();
  const go = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => { e.preventDefault(); navigate(href); };

  const services = [1, 2, 3, 4, 5, 6].map((i) => ({
    icon: serviceIcons[i - 1],
    title: t(`svc.${i}.title`),
    desc: t(`svc.${i}.desc`),
  }));

  const values = [1, 2, 3, 4].map((i) => ({
    icon: valueEmojis[i - 1],
    title: t(`val.${i}.title`),
    desc: t(`val.${i}.desc`),
  }));

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* ── HERO ── */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img src="/manus-storage/hero-bg_4b904b9a.jpg" alt="Ungubani construção" className="w-full h-full object-cover" />
          <div className="absolute inset-0" style={{ background: "linear-gradient(105deg, oklch(0.12 0.05 255 / 0.88) 0%, oklch(0.12 0.05 255 / 0.55) 60%, transparent 100%)" }} />
        </div>
        <div className="container relative z-10 pt-28 pb-20">
          <div className="max-w-2xl">
            <div className="section-label section-label--light mb-6">{t("home.hero.tag")}</div>
            <h1 className="text-white mb-6" style={{ fontSize: "clamp(2.8rem, 6vw, 5rem)", lineHeight: 1.05 }}>
              {t("home.hero.h1a")}<br />{t("home.hero.h1b")}<br />
              <span style={{ color: "oklch(0.63 0.11 240)" }}>{t("home.hero.h1c")}<br />{t("home.hero.h1d")}</span>
            </h1>
            <p className="text-white/70 text-lg mb-10 max-w-lg leading-relaxed">{t("home.hero.sub")}</p>
            <div className="flex flex-wrap gap-4">
              <a href="/projetos" onClick={(e) => go(e, "/projetos")}
                className="btn-solid btn-press inline-flex items-center gap-2 px-7 py-3.5 text-white font-bold text-sm tracking-widest uppercase rounded"
                style={{ background: "oklch(0.50 0.14 255)" }}>
                {t("home.hero.cta1")} <ArrowRight size={16} />
              </a>
              <a href="/contactos" onClick={(e) => go(e, "/contactos")}
                className="btn-outline btn-press inline-flex items-center gap-2 px-7 py-3.5 text-white font-bold text-sm tracking-widest uppercase rounded border border-white/30 hover:border-white/60 hover:bg-white/10">
                {t("home.hero.cta2")}
              </a>
            </div>
          </div>
        </div>
        <a href="#stats" className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/40 hover:text-white/70 transition-colors animate-bounce">
          <ChevronDown size={24} />
        </a>
      </section>

      {/* ── STATS BAR ── */}
      <section id="stats" style={{ background: "oklch(0.22 0.06 255)" }}>
        <div className="container py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { n: 15, s: "+", labelKey: "home.stats.years" },
              { n: 80, s: "+", labelKey: "home.stats.projects" },
              { n: 4, s: "", labelKey: "home.stats.class" },
              { n: 100, s: "%", labelKey: "home.stats.quality" },
            ].map((stat) => (
              <div key={stat.labelKey}>
                <div className="text-white font-black mb-1" style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "clamp(2.2rem, 4vw, 3.2rem)" }}>
                  <Counter target={stat.n} suffix={stat.s} />
                </div>
                <div className="text-white/45 text-[0.68rem] font-semibold tracking-[0.16em] uppercase">{t(stat.labelKey)}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── ABOUT ── */}
      <section className="section-light py-24">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <img src="/manus-storage/about-construction_832472cf.jpg" alt="Ungubani equipa" className="w-full h-[480px] object-cover rounded-sm" />
              <div className="absolute -bottom-6 -right-6 hidden lg:flex flex-col items-center justify-center w-32 h-32 rounded-sm text-white"
                style={{ background: "oklch(0.50 0.14 255)" }}>
                <div className="font-black text-3xl" style={{ fontFamily: "'Barlow Condensed', sans-serif" }}>+15</div>
                <div className="text-[0.6rem] tracking-widest uppercase text-center leading-tight mt-1">{t("home.stats.years")}</div>
              </div>
            </div>
            <div className="fade-up">
              <div className="section-label">{t("home.about.tag")}</div>
              <h2 className="text-head-adaptive mb-6" style={{ fontSize: "clamp(2rem, 3.5vw, 2.8rem)" }}>{t("home.about.h2")}</h2>
              <div className="divider mb-6" />
              <p className="text-body-adaptive mb-5 leading-relaxed">{t("home.about.p1")}</p>
              <p className="text-body-adaptive mb-8 leading-relaxed">{t("home.about.p2")}</p>
              <div className="flex items-start gap-3 p-4 rounded-sm mb-8" style={{ background: "oklch(0.22 0.06 255 / 0.08)", borderLeft: "3px solid oklch(0.50 0.14 255)" }}>
                <Award size={20} className="flex-shrink-0 mt-0.5" style={{ color: "oklch(0.50 0.14 255)" }} />
                <p className="text-body-adaptive text-sm leading-relaxed">{t("home.about.alvara")}</p>
              </div>
              <a href="/quem-somos" onClick={(e) => go(e, "/quem-somos")}
                className="btn-solid btn-press inline-flex items-center gap-2 px-6 py-3 font-bold text-sm tracking-widest uppercase text-white rounded"
                style={{ background: "oklch(0.22 0.06 255)" }}>
                {t("home.about.cta")} <ArrowRight size={15} />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── SERVICES ── */}
      <section className="section-alt py-24">
        <div className="container">
          <div className="text-center mb-14 fade-up">
            <div className="section-label" style={{ justifyContent: "center" }}>{t("home.services.tag")}</div>
            <h2 className="text-head-adaptive" style={{ fontSize: "clamp(2rem, 3.5vw, 2.8rem)" }}>{t("home.services.h2")}</h2>
            <div className="divider divider--center mt-4" />
            <p className="text-muted-adaptive mt-4 max-w-xl mx-auto text-sm leading-relaxed">{t("home.services.sub")}</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s, i) => (
              <div key={i} className="card-adaptive fade-up p-7 rounded-sm border hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group cursor-default">
                <div className="w-10 h-10 rounded flex items-center justify-center mb-5 text-white transition-all duration-300 group-hover:scale-110"
                  style={{ background: "oklch(0.22 0.06 255)" }}>
                  {s.icon}
                </div>
                <h4 className="text-head-adaptive font-bold mb-2 text-[0.95rem] leading-snug">{s.title}</h4>
                <p className="text-muted-adaptive text-sm leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PROJECTS ── */}
      <section className="section-light py-24">
        <div className="container">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-14">
            <div className="fade-up">
              <div className="section-label">{t("home.projects.tag")}</div>
              <h2 className="text-head-adaptive" style={{ fontSize: "clamp(2rem, 3.5vw, 2.8rem)" }}>{t("home.projects.h2")}</h2>
              <div className="divider mt-4" />
            </div>
            <a href="/projetos" onClick={(e) => go(e, "/projetos")}
              className="btn-outline fade-up inline-flex items-center gap-2 text-sm font-bold tracking-widest uppercase border px-5 py-2.5 rounded"
              style={{ borderColor: "oklch(0.50 0.14 255)", color: "oklch(0.50 0.14 255)" }}>
              {t("home.projects.cta")} <ArrowRight size={14} />
            </a>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {projects.map((p, i) => (
              <div key={i} className="fade-up group relative overflow-hidden rounded-sm cursor-pointer" style={{ height: "380px" }}>
                <img src={p.img} alt={t(p.titleKey)} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <div className="absolute inset-0 transition-opacity duration-300" style={{ background: "linear-gradient(to top, oklch(0.12 0.05 255 / 0.92) 0%, oklch(0.12 0.05 255 / 0.3) 60%, transparent 100%)" }} />
                <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                  <span className="inline-block text-[0.62rem] font-bold tracking-widest uppercase px-2.5 py-1 rounded mb-3"
                    style={{ background: "oklch(0.50 0.14 255)", color: "white" }}>
                    {t(p.catKey)}
                  </span>
                  <h4 className="text-white font-bold text-base mb-1">{t(p.titleKey)}</h4>
                  <p className="text-white/50 text-xs tracking-wider mb-2">{t(p.locKey)}</p>
                  <p className="text-white/70 text-xs leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-300 max-h-0 group-hover:max-h-20 overflow-hidden">{t(p.descKey)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRIME INFINITY CTA ── */}
      <section className="relative py-28 overflow-hidden">
        <div className="absolute inset-0">
          <img src="/manus-storage/prime-infinity_fbdb134d.jpg" alt="Prime Infinity Residences" className="w-full h-full object-cover" />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to right, oklch(0.12 0.05 255 / 0.92) 0%, oklch(0.12 0.05 255 / 0.6) 60%, transparent 100%)" }} />
        </div>
        <div className="container relative z-10">
          <div className="max-w-xl fade-up">
            <div className="section-label section-label--light">{t("home.prime.tag")}</div>
            <h2 className="text-white mb-5" style={{ fontSize: "clamp(2rem, 3.5vw, 2.8rem)" }}>
              {t("home.prime.h2a")}<br />{t("home.prime.h2b")}
            </h2>
            <div className="divider divider--sky mb-6" />
            <p className="text-white/70 mb-8 leading-relaxed">{t("home.prime.sub")}</p>
            <div className="flex flex-wrap gap-4">
              <a href="/prime-infinity" onClick={(e) => go(e, "/prime-infinity")}
                className="btn-solid btn-press inline-flex items-center gap-2 px-7 py-3.5 text-white font-bold text-sm tracking-widest uppercase rounded"
                style={{ background: "oklch(0.50 0.14 255)" }}>
                {t("home.prime.cta1")} <ArrowRight size={15} />
              </a>
              <a href="/contactos" onClick={(e) => go(e, "/contactos")}
                className="btn-outline btn-press inline-flex items-center gap-2 px-7 py-3.5 text-white font-bold text-sm tracking-widest uppercase rounded border border-white/30 hover:border-white/60 hover:bg-white/10">
                {t("home.prime.cta2")}
              </a>
            </div>
          </div>
        </div>
        <div className="absolute top-6 right-8 hidden lg:block">
          <div className="text-white/20 font-black" style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "7rem", lineHeight: 1 }}>2025</div>
          <div className="text-white/30 text-[0.68rem] tracking-[0.2em] uppercase text-right">{t("home.prime.year")}</div>
        </div>
      </section>

      {/* ── VALUES ── */}
      <section className="py-24" style={{ background: "oklch(0.22 0.06 255)" }}>
        <div className="container">
          <div className="text-center mb-14 fade-up">
            <div className="section-label section-label--light" style={{ justifyContent: "center" }}>{t("home.values.tag")}</div>
            <h2 className="text-white" style={{ fontSize: "clamp(2rem, 3.5vw, 2.8rem)" }}>{t("home.values.h2")}</h2>
            <div className="divider divider--sky divider--center mt-4" />
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v, i) => (
              <div key={i} className="fade-up text-center p-8 rounded-sm border border-white/8 hover:border-white/20 hover:-translate-y-1 transition-all duration-300">
                <div className="text-3xl mb-4 transition-transform duration-300 hover:scale-110 inline-block">{v.icon}</div>
                <h4 className="text-white font-bold mb-2">{v.title}</h4>
                <p className="text-white/50 text-sm leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA FINAL ── */}
      <section className="section-alt py-20">
        <div className="container text-center fade-up">
          <div className="section-label" style={{ justifyContent: "center" }}>{t("home.cta.tag")}</div>
          <h2 className="text-head-adaptive mb-4" style={{ fontSize: "clamp(2rem, 3.5vw, 2.8rem)" }}>{t("home.cta.h2")}</h2>
          <p className="text-muted-adaptive mb-8 max-w-md mx-auto text-sm leading-relaxed">{t("home.cta.sub")}</p>
          <a href="/contactos" onClick={(e) => go(e, "/contactos")}
            className="btn-solid btn-press inline-flex items-center gap-2 px-8 py-4 text-white font-bold text-sm tracking-widest uppercase rounded"
            style={{ background: "oklch(0.22 0.06 255)" }}>
            {t("home.cta.btn")} <ArrowRight size={15} />
          </a>
        </div>
      </section>

      <Footer />
    </div>
  );
}
