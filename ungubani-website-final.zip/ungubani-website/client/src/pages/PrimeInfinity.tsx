/* ============================================================
   UNGUBANI — Prime Infinity Residences
   Fully translated via LanguageContext (PT/EN)
   ============================================================ */
import { useEffect } from "react";
import { ArrowRight, CheckCircle, Star } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useTransitionNavigate } from "@/components/PageTransition";
import { useLanguage } from "@/contexts/LanguageContext";

function useFadeUp() {
  useEffect(() => {
    const els = document.querySelectorAll(".fade-up");
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.1 });
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);
}

export default function PrimeInfinity() {
  useFadeUp();
  const navigate = useTransitionNavigate();
  const { t } = useLanguage();
  const go = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => { e.preventDefault(); navigate(href); };

  const features = [1, 2, 3, 4, 5, 6, 7, 8].map((i) => t(`prime.feat.${i}`));

  const timeline = [
    { phaseKey: "prime.tl.1.phase", titleKey: "prime.tl.1.title", statusKey: "prime.tl.1.status", active: false },
    { phaseKey: "prime.tl.2.phase", titleKey: "prime.tl.2.title", statusKey: "prime.tl.2.status", active: true },
    { phaseKey: "prime.tl.3.phase", titleKey: "prime.tl.3.title", statusKey: "prime.tl.3.status", active: false },
    { phaseKey: "prime.tl.4.phase", titleKey: "prime.tl.4.title", statusKey: "prime.tl.4.status", active: false },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="relative min-h-[70vh] flex items-end pb-20 overflow-hidden">
        <div className="absolute inset-0">
          <img src="/manus-storage/prime-infinity_fbdb134d.jpg" alt="Prime Infinity Residences" className="w-full h-full object-cover" />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to top, oklch(0.12 0.05 255 / 0.95) 0%, oklch(0.12 0.05 255 / 0.5) 60%, transparent 100%)" }} />
        </div>
        <div className="container relative z-10 pt-36">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded mb-5 text-[0.65rem] font-bold tracking-widest uppercase"
            style={{ background: "oklch(0.50 0.14 255 / 0.2)", border: "1px solid oklch(0.50 0.14 255 / 0.4)", color: "oklch(0.75 0.10 240)" }}>
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            {t("prime.hero.badge")}
          </div>
          <h1 className="text-white mb-4" style={{ fontSize: "clamp(2.5rem, 6vw, 5rem)" }}>
            Prime Infinity<br />Residences
          </h1>
          <div className="divider divider--sky mb-6" />
          <p className="text-white/70 max-w-xl leading-relaxed text-lg">{t("prime.hero.sub")}</p>
        </div>
      </section>

      {/* Stats */}
      <section style={{ background: "oklch(0.22 0.06 255)" }}>
        <div className="container py-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { n: "T2–T4", labelKey: "prime.stat.types" },
              { n: "A",     labelKey: "prime.stat.energy" },
              { n: "2025",  labelKey: "prime.stat.launch" },
              { n: "∞",     labelKey: "prime.stat.views" },
            ].map((s) => (
              <div key={s.labelKey}>
                <div className="text-white font-black mb-1" style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}>{s.n}</div>
                <div className="text-white/45 text-[0.68rem] font-semibold tracking-[0.16em] uppercase">{t(s.labelKey)}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Concept */}
      <section className="section-light py-24">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="fade-up">
              <div className="section-label">{t("prime.concept.tag")}</div>
              <h2 className="text-head-adaptive mb-5" style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}>
                {t("prime.concept.h2")}
              </h2>
              <div className="divider mb-6" />
              <p className="text-body-adaptive mb-5 leading-relaxed">{t("prime.concept.p1")}</p>
              <p className="text-body-adaptive mb-8 leading-relaxed">{t("prime.concept.p2")}</p>
              <div className="flex gap-3">
                <a href="/contactos" onClick={(e) => go(e, "/contactos")}
                  className="btn-press inline-flex items-center gap-2 px-6 py-3 text-white font-bold text-sm tracking-widest uppercase rounded transition-all duration-200 hover:-translate-y-0.5"
                  style={{ background: "oklch(0.22 0.06 255)" }}>
                  {t("prime.concept.cta")} <ArrowRight size={14} />
                </a>
              </div>
            </div>
            <div className="fade-up">
              <img src="/manus-storage/prime-infinity_fbdb134d.jpg" alt="Prime Infinity" className="w-full h-[420px] object-cover rounded-sm" />
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="section-alt py-24">
        <div className="container">
          <div className="text-center mb-14 fade-up">
            <div className="section-label" style={{ justifyContent: "center" }}>{t("prime.features.tag")}</div>
            <h2 className="text-head-adaptive" style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}>{t("prime.features.h2")}</h2>
            <div className="divider divider--center mt-4" />
          </div>
          <div className="grid sm:grid-cols-2 gap-4 max-w-3xl mx-auto">
            {features.map((f, i) => (
              <div key={i} className="card-adaptive fade-up flex items-center gap-3 p-4 rounded-sm border">
                <CheckCircle size={16} className="flex-shrink-0" style={{ color: "oklch(0.50 0.14 255)" }} />
                <span className="text-body-adaptive text-sm">{f}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-24" style={{ background: "oklch(0.22 0.06 255)" }}>
        <div className="container">
          <div className="text-center mb-14 fade-up">
            <div className="section-label section-label--light" style={{ justifyContent: "center" }}>{t("prime.timeline.tag")}</div>
            <h2 className="text-white" style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}>{t("prime.timeline.h2")}</h2>
            <div className="divider divider--sky divider--center mt-4" />
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {timeline.map((tl, i) => (
              <div key={i} className={`fade-up p-6 rounded-sm border transition-colors duration-300 ${tl.active ? "border-sky-400/50" : "border-white/8"}`}
                style={{ background: tl.active ? "oklch(0.30 0.08 255)" : "transparent" }}>
                {tl.active && <Star size={14} className="mb-3 text-sky-400" />}
                <div className="text-[0.65rem] font-bold tracking-widest uppercase mb-2" style={{ color: "oklch(0.63 0.11 240)" }}>{t(tl.phaseKey)}</div>
                <h4 className="text-white font-bold mb-2 text-sm">{t(tl.titleKey)}</h4>
                <span className={`text-[0.68rem] font-semibold tracking-wider uppercase px-2 py-0.5 rounded ${tl.active ? "bg-green-500/20 text-green-400" : "text-white/40"}`}>
                  {t(tl.statusKey)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Interest CTA */}
      <section className="section-light py-20">
        <div className="container max-w-2xl text-center fade-up">
          <div className="section-label" style={{ justifyContent: "center" }}>{t("prime.cta.tag")}</div>
          <h2 className="text-head-adaptive mb-4" style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}>
            {t("prime.cta.h2")}
          </h2>
          <p className="text-muted-adaptive mb-8 text-sm leading-relaxed">{t("prime.cta.sub")}</p>
          <a href="/contactos" onClick={(e) => go(e, "/contactos")}
            className="btn-press inline-flex items-center gap-2 px-8 py-4 text-white font-bold text-sm tracking-widest uppercase rounded transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl"
            style={{ background: "oklch(0.22 0.06 255)" }}>
            {t("prime.cta.btn")} <ArrowRight size={15} />
          </a>
        </div>
      </section>

      <Footer />
    </div>
  );
}
