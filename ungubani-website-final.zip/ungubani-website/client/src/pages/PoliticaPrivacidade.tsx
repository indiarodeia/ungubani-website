/* ============================================================
   UNGUBANI — Política de Privacidade
   Placeholder RGPD-compliant — substituir com texto jurídico real
   ============================================================ */
import { useEffect } from "react";
import { ArrowLeft, ShieldCheck } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useTransitionNavigate } from "@/components/PageTransition";
import { useLanguage } from "@/contexts/LanguageContext";

function useFadeUp() {
  useEffect(() => {
    const els = document.querySelectorAll(".fade-up");
    const obs = new IntersectionObserver(
      (entries) => { entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); }); },
      { threshold: 0.08 }
    );
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);
}

const sections = [
  {
    title: "1. Responsável pelo Tratamento",
    content: `A Ungubani — Construção Civil e Obras Públicas, com sede nos Açores, Portugal, é a entidade responsável pelo tratamento dos dados pessoais recolhidos através deste website.

Para questões relacionadas com a proteção de dados, pode contactar-nos através do email geral@ungubani.pt.`,
  },
  {
    title: "2. Dados Recolhidos",
    content: `Recolhemos os seguintes dados pessoais quando preenche o formulário de contacto:
• Nome completo
• Endereço de email
• Número de telefone (opcional)
• Mensagem e assunto do contacto

Adicionalmente, o website pode recolher dados técnicos de navegação (endereço IP, tipo de browser, páginas visitadas) através de cookies analíticos, mediante o seu consentimento.`,
  },
  {
    title: "3. Finalidade e Base Legal",
    content: `Os seus dados pessoais são tratados para as seguintes finalidades:

• Resposta a pedidos de informação e contacto (base legal: execução de contrato ou diligências pré-contratuais, art. 6.º, n.º 1, al. b) do RGPD)
• Análise estatística de utilização do website (base legal: consentimento, art. 6.º, n.º 1, al. a) do RGPD)

Não utilizamos os seus dados para fins de marketing direto sem consentimento explícito.`,
  },
  {
    title: "4. Cookies",
    content: `Este website utiliza cookies para melhorar a experiência de navegação:

Cookies Essenciais — necessários para o funcionamento do website, não requerem consentimento.
Cookies Analíticos — utilizados para compreender como os visitantes interagem com o website, de forma anónima. Apenas ativados com o seu consentimento.

Pode gerir as suas preferências de cookies a qualquer momento através do banner de consentimento ou das definições do seu browser.`,
  },
  {
    title: "5. Conservação dos Dados",
    content: `Os dados recolhidos através do formulário de contacto são conservados pelo período necessário à gestão do pedido e, subsequentemente, pelo prazo legalmente exigido.

Os dados de navegação recolhidos por cookies analíticos são conservados por um período máximo de 13 meses.`,
  },
  {
    title: "6. Partilha de Dados",
    content: `A Ungubani não vende, aluga nem partilha os seus dados pessoais com terceiros para fins comerciais.

Os dados podem ser partilhados com prestadores de serviços técnicos (ex: alojamento web) que atuam como subcontratantes, estando vinculados a obrigações de confidencialidade e segurança.`,
  },
  {
    title: "7. Os Seus Direitos",
    content: `Ao abrigo do Regulamento Geral sobre a Proteção de Dados (RGPD), tem os seguintes direitos:

• Direito de acesso aos seus dados pessoais
• Direito de retificação de dados inexatos
• Direito ao apagamento ("direito a ser esquecido")
• Direito à limitação do tratamento
• Direito à portabilidade dos dados
• Direito de oposição ao tratamento
• Direito de retirar o consentimento a qualquer momento

Para exercer qualquer destes direitos, contacte-nos através de geral@ungubani.pt. Tem ainda o direito de apresentar reclamação à Comissão Nacional de Proteção de Dados (CNPD) em www.cnpd.pt.`,
  },
  {
    title: "8. Segurança",
    content: `Implementamos medidas técnicas e organizativas adequadas para proteger os seus dados pessoais contra acesso não autorizado, perda, destruição ou divulgação.`,
  },
  {
    title: "9. Alterações a esta Política",
    content: `Esta Política de Privacidade pode ser atualizada periodicamente. A data da última atualização é indicada no topo da página. Recomendamos que consulte esta página regularmente.`,
  },
  {
    title: "10. Contacto",
    content: `Para qualquer questão relacionada com a proteção dos seus dados pessoais:

Email: geral@ungubani.pt
Morada: Açores, Portugal`,
  },
];

export default function PoliticaPrivacidade() {
  useFadeUp();
  const navigate = useTransitionNavigate();
  const { t } = useLanguage();
  const go = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => { e.preventDefault(); navigate(href); };

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-36 pb-16" style={{ background: "oklch(0.22 0.06 255)" }}>
        <div className="container">
          <a
            href="/"
            onClick={(e) => go(e, "/")}
            className="inline-flex items-center gap-2 text-white/50 hover:text-white transition-colors duration-200 text-xs font-semibold tracking-widest uppercase mb-6"
          >
            <ArrowLeft size={14} /> Voltar ao Início
          </a>
          <div className="flex items-center gap-3 mb-4">
            <ShieldCheck size={28} style={{ color: "oklch(0.63 0.11 240)" }} />
            <h1 className="text-white" style={{ fontSize: "clamp(2rem, 4vw, 3rem)" }}>
              Política de Privacidade
            </h1>
          </div>
          <div className="divider divider--sky mb-4" />
          <p className="text-white/50 text-sm">
            Última atualização: Julho de 2025 &nbsp;·&nbsp; Em conformidade com o RGPD (Regulamento UE 2016/679)
          </p>
        </div>
      </section>

      {/* Disclaimer banner */}
      <div className="py-3" style={{ background: "oklch(0.50 0.14 255 / 0.12)", borderBottom: "1px solid oklch(0.50 0.14 255 / 0.2)" }}>
        <div className="container">
          <p className="text-[0.75rem] text-center" style={{ color: "oklch(0.50 0.14 255)" }}>
            <strong>Nota:</strong> Este documento é um modelo de referência. Recomenda-se a revisão por um profissional jurídico especializado em proteção de dados antes da publicação definitiva.
          </p>
        </div>
      </div>

      {/* Content */}
      <section className="py-16" style={{ background: "oklch(0.985 0.003 90)" }}>
        <div className="container">
          <div className="max-w-3xl mx-auto">
            {/* Table of contents */}
            <div className="fade-up p-6 rounded-sm border border-gray-100 mb-12" style={{ background: "white" }}>
              <h3 className="text-gray-900 font-bold mb-4 text-sm tracking-widest uppercase">Índice</h3>
              <ol className="space-y-1.5">
                {sections.map((s, i) => (
                  <li key={i}>
                    <a
                      href={`#section-${i}`}
                      className="text-sm transition-colors duration-200 hover:underline"
                      style={{ color: "oklch(0.50 0.14 255)" }}
                      onClick={(e) => {
                        e.preventDefault();
                        document.getElementById(`section-${i}`)?.scrollIntoView({ behavior: "smooth" });
                      }}
                    >
                      {s.title}
                    </a>
                  </li>
                ))}
              </ol>
            </div>

            {/* Sections */}
            <div className="space-y-10">
              {sections.map((s, i) => (
                <div key={i} id={`section-${i}`} className="fade-up scroll-mt-24">
                  <h2
                    className="font-bold mb-4 pb-3 border-b"
                    style={{
                      fontSize: "1.05rem",
                      color: "oklch(0.15 0.01 255)",
                      borderColor: "oklch(0.92 0.004 286.32)",
                    }}
                  >
                    {s.title}
                  </h2>
                  <div className="text-gray-600 text-sm leading-relaxed whitespace-pre-line">
                    {s.content}
                  </div>
                </div>
              ))}
            </div>

            {/* Back to top */}
            <div className="mt-16 pt-8 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-4">
              <a
                href="/"
                onClick={(e) => go(e, "/")}
                className="inline-flex items-center gap-2 text-sm font-bold tracking-widest uppercase transition-colors duration-200"
                style={{ color: "oklch(0.50 0.14 255)" }}
              >
                <ArrowLeft size={14} /> Voltar ao Início
              </a>
              <a
                href="/contactos"
                onClick={(e) => go(e, "/contactos")}
                className="inline-flex items-center gap-2 text-sm font-bold tracking-widest uppercase transition-colors duration-200"
                style={{ color: "oklch(0.50 0.14 255)" }}
              >
                Contactar sobre Privacidade →
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
