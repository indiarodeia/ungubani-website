import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import { PageTransitionProvider } from "./components/PageTransition";
import CookieBanner from "./components/CookieBanner";
import BackToTop from "./components/BackToTop";
import Home from "./pages/Home";
import QuemSomos from "./pages/QuemSomos";
import Projetos from "./pages/Projetos";
import PrimeInfinity from "./pages/PrimeInfinity";
import Contactos from "./pages/Contactos";
import PoliticaPrivacidade from "./pages/PoliticaPrivacidade";
import NotFound from "./pages/NotFound";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/quem-somos" component={QuemSomos} />
      <Route path="/projetos" component={Projetos} />
      <Route path="/prime-infinity" component={PrimeInfinity} />
      <Route path="/contactos" component={Contactos} />
      <Route path="/politica-de-privacidade" component={PoliticaPrivacidade} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <LanguageProvider>
      <ThemeProvider defaultTheme="light" switchable>
        <TooltipProvider>
          <Toaster />
          <PageTransitionProvider>
            <Router />
            <CookieBanner />
            <BackToTop />
          </PageTransitionProvider>
        </TooltipProvider>
      </ThemeProvider>
      </LanguageProvider>
    </ErrorBoundary>
  );
}
