/* ============================================================
   UNGUBANI — Footer
   Design: "Monolithic Authority" — dark navy, clean grid
   Fully translated via LanguageContext (PT/EN)
   ============================================================ */
import { MapPin, Phone, Mail } from "lucide-react";
import { useTransitionNavigate } from "./PageTransition";
import { useLanguage } from "@/contexts/LanguageContext";

export default function Footer() {
  const navigate = useTransitionNavigate();
  const { t } = useLanguage();

  const handleNav = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (href.startsWith("http") || href.startsWith("mailto") || href.startsWith("tel")) return;
    e.preventDefault();
    navigate(href);
  };

  const navLinks = [
    { href: "/", labelKey: "nav.home" },
    { href: "/quem-somos", labelKey: "nav.about" },
    { href: "/projetos", labelKey: "nav.projects" },
    { href: "/prime-infinity", labelKey: "nav.prime" },
    { href: "/contactos", labelKey: "nav.contact" },
  ];

  const serviceKeys = [
    "svc.1.title", "svc.2.title", "svc.3.title",
    "svc.4.title", "svc.5.title", "svc.6.title",
  ];

  return (
    <footer style={{ background: "oklch(0.13 0.04 255)", color: "rgba(255,255,255,0.55)" }}>
      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <a href="/" onClick={(e) => handleNav(e, "/")} className="flex items-center mb-4">
              <img
              src="/manus-storage/ungubanilogo-white_f048e63d.svg"
              alt="Ungubani"
              className="h-14 w-auto transition-transform duration-200 hover:scale-105"
              />
            </a>
            <p className="text-sm leading-relaxed mb-5">{t("footer.tagline")}</p>
            <div className="flex gap-2">
              {[
                { label: "f", title: "Facebook" },
                { label: "ig", title: "Instagram" },
                { label: "in", title: "LinkedIn" },
              ].map((s) => (
                <a key={s.label} href="#" title={s.title}
                  className="w-8 h-8 rounded border border-white/10 flex items-center justify-center text-xs text-white/40 hover:border-sky-400/50 hover:text-sky-400 transition-all duration-200 hover:scale-110 hover:-translate-y-0.5">
                  {s.label}
                </a>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h5 className="text-white text-[0.68rem] font-bold tracking-[0.18em] uppercase mb-4">{t("footer.nav")}</h5>
            <ul className="space-y-2.5">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <a href={l.href} onClick={(e) => handleNav(e, l.href)}
                    className="text-sm hover:text-white transition-colors duration-200 hover:translate-x-1 inline-block"
                    style={{ transition: "color 200ms ease, transform 200ms ease" }}>
                    {t(l.labelKey)}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h5 className="text-white text-[0.68rem] font-bold tracking-[0.18em] uppercase mb-4">{t("footer.services")}</h5>
            <ul className="space-y-2.5">
              {serviceKeys.map((key) => (
                <li key={key}>
                  <a href="/quem-somos" onClick={(e) => handleNav(e, "/quem-somos")}
                    className="text-sm hover:text-white transition-colors duration-200 inline-block"
                    style={{ transition: "color 200ms ease, transform 200ms ease" }}>
                    {t(key)}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h5 className="text-white text-[0.68rem] font-bold tracking-[0.18em] uppercase mb-4">{t("footer.contact")}</h5>
            <div className="space-y-3">
              <div className="flex gap-2.5 items-start text-sm">
                <MapPin size={14} className="mt-0.5 flex-shrink-0 text-sky-400/70" />
                <span>{t("contact.address.val")}</span>
              </div>
              <div className="flex gap-2.5 items-center text-sm">
                <Phone size={14} className="flex-shrink-0 text-sky-400/70" />
                <a href="tel:+351000000000" className="hover:text-white transition-colors">{t("contact.phone.val")}</a>
              </div>
              <div className="flex gap-2.5 items-center text-sm">
                <Mail size={14} className="flex-shrink-0 text-sky-400/70" />
                <a href="mailto:geral@ungubani.pt" className="hover:text-white transition-colors">geral@ungubani.pt</a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/8 pt-6 flex flex-col sm:flex-row justify-between items-center gap-3 text-[0.75rem]">
          <span>{t("footer.rights")}</span>
          <div className="flex flex-wrap items-center gap-4">
            <a href="/politica-de-privacidade" onClick={(e) => handleNav(e, "/politica-de-privacidade")}
              className="hover:text-white transition-colors duration-200">
              {t("footer.privacy")}
            </a>
            <span>{t("footer.location")}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
