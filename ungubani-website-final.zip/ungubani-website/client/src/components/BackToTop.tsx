/* ============================================================
   UNGUBANI — Back to Top floating button
   Appears after scrolling 400px, smooth scroll to top on click
   Positioned above the cookie banner when visible
   ============================================================ */
import { useState, useEffect } from "react";
import { ArrowUp } from "lucide-react";

export default function BackToTop() {
  const [visible, setVisible] = useState(false);
  const [hovered, setHovered] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <button
      onClick={scrollToTop}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      aria-label="Voltar ao topo"
      title="Voltar ao topo"
      style={{
        position: "fixed",
        bottom: "5.5rem",   /* sits above the cookie banner */
        right: "1.5rem",
        zIndex: 9990,
        width: "44px",
        height: "44px",
        borderRadius: "4px",
        border: "1px solid oklch(0.40 0.08 255)",
        background: hovered
          ? "oklch(0.50 0.14 255)"
          : "oklch(0.22 0.06 255)",
        color: "white",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        boxShadow: hovered
          ? "0 8px 24px rgba(0,0,0,0.40)"
          : "0 4px 16px rgba(0,0,0,0.30)",
        opacity: visible ? 1 : 0,
        transform: visible
          ? hovered ? "translateY(-3px) scale(1.05)" : "translateY(0) scale(1)"
          : "translateY(12px) scale(0.9)",
        pointerEvents: visible ? "auto" : "none",
        transition:
          "opacity 280ms cubic-bezier(0.23,1,0.32,1), transform 280ms cubic-bezier(0.23,1,0.32,1), background 200ms ease, box-shadow 200ms ease",
      }}
    >
      <ArrowUp
        size={18}
        style={{
          transition: "transform 200ms ease",
          transform: hovered ? "translateY(-2px)" : "translateY(0)",
        }}
      />
    </button>
  );
}
