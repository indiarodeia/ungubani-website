/* ============================================================
   UNGUBANI — Cookie Consent Banner (RGPD / GDPR compliant)
   - Stores consent in localStorage
   - Three states: accepted, rejected, or pending
   - Links to Privacy Policy page
   ============================================================ */
import { useState, useEffect } from "react";
import { X, Cookie, ShieldCheck, BarChart2 } from "lucide-react";
import { useTransitionNavigate } from "./PageTransition";
import { useLanguage } from "@/contexts/LanguageContext";

type ConsentState = "pending" | "accepted" | "rejected";

const STORAGE_KEY = "ungubani_cookie_consent";
const STORAGE_VERSION = "1"; // bump to reset consent on policy changes

export default function CookieBanner() {
  const [state, setState] = useState<ConsentState>("pending");
  const [visible, setVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const navigate = useTransitionNavigate();
  const { t } = useLanguage();

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.version === STORAGE_VERSION) {
          setState(parsed.choice);
          return;
        }
      }
    } catch {}
    // Show banner after a short delay so it doesn't flash on first paint
    const t = setTimeout(() => setVisible(true), 900);
    return () => clearTimeout(t);
  }, []);

  const save = (choice: "accepted" | "rejected") => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ choice, version: STORAGE_VERSION, date: new Date().toISOString() }));
    } catch {}
    setState(choice);
    setVisible(false);
  };

  const handlePolicyLink = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    navigate("/politica-de-privacidade");
  };

  if (state !== "pending" || !visible) return null;

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-[9998] px-4 pb-4"
      style={{ animation: "slideUpBanner 400ms cubic-bezier(0.23,1,0.32,1) both" }}
    >
      <style>{`
        @keyframes slideUpBanner {
          from { transform: translateY(110%); opacity: 0; }
          to   { transform: translateY(0);    opacity: 1; }
        }
      `}</style>

      <div
        className="max-w-4xl mx-auto rounded-sm overflow-hidden"
        style={{
          background: "oklch(0.14 0.04 255)",
          border: "1px solid oklch(0.30 0.06 255)",
          boxShadow: "0 -4px 40px rgba(0,0,0,0.45)",
        }}
      >
        {/* Main row */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-5">
          <Cookie size={22} className="flex-shrink-0 mt-0.5 sm:mt-0" style={{ color: "oklch(0.63 0.11 240)" }} />

          <div className="flex-1 min-w-0">
            <p className="text-white text-sm leading-relaxed">
              {t("cookie.text")}{" "}
              <a
                href="/politica-de-privacidade"
                onClick={handlePolicyLink}
                className="underline underline-offset-2 transition-colors duration-200"
                style={{ color: "oklch(0.63 0.11 240)" }}
              >
                {t("cookie.policy")}
              </a>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 flex-shrink-0">
            <button
              onClick={() => setShowDetails((v) => !v)}
              className="text-[0.72rem] font-semibold tracking-wider uppercase px-3 py-2 rounded transition-all duration-200 hover:-translate-y-0.5"
              style={{ color: "oklch(0.63 0.11 240)", border: "1px solid oklch(0.30 0.06 255)" }}
            >
              {showDetails ? "✕" : t("cookie.details")}
            </button>
            <button
              onClick={() => save("rejected")}
              className="text-[0.72rem] font-bold tracking-wider uppercase px-4 py-2 rounded transition-all duration-200 hover:-translate-y-0.5"
              style={{ color: "rgba(255,255,255,0.55)", border: "1px solid oklch(0.30 0.06 255)" }}
            >
              {t("cookie.reject")}
            </button>
            <button
              onClick={() => save("accepted")}
              className="text-[0.72rem] font-bold tracking-wider uppercase px-5 py-2 rounded text-white transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg"
              style={{ background: "oklch(0.50 0.14 255)" }}
            >
              {t("cookie.accept")}
            </button>
          </div>
        </div>

        {/* Details panel */}
        {showDetails && (
          <div
            className="border-t px-5 pb-5 pt-4 grid sm:grid-cols-2 gap-4"
            style={{ borderColor: "oklch(0.25 0.05 255)" }}
          >
            {[
              {
                icon: <ShieldCheck size={16} />,
                title: t("cookie.essential.title"),
                desc: t("cookie.essential.desc"),
                required: true,
              },
              {
                icon: <BarChart2 size={16} />,
                title: t("cookie.analytics.title"),
                desc: t("cookie.analytics.desc"),
                required: false,
              },
            ].map((cat) => (
              <div
                key={cat.title}
                className="flex gap-3 p-3 rounded-sm"
                style={{ background: "oklch(0.20 0.05 255)" }}
              >
                <div className="flex-shrink-0 mt-0.5" style={{ color: "oklch(0.63 0.11 240)" }}>
                  {cat.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-white text-[0.78rem] font-bold">{cat.title}</span>
                    <span
                      className="text-[0.6rem] font-bold tracking-wider uppercase px-2 py-0.5 rounded"
                      style={{
                        background: cat.required ? "oklch(0.50 0.14 255 / 0.2)" : "oklch(0.30 0.06 255)",
                        color: cat.required ? "oklch(0.75 0.10 240)" : "rgba(255,255,255,0.4)",
                      }}
                    >
                      {cat.required ? t("cookie.required") : t("cookie.optional")}
                    </span>
                  </div>
                  <p className="text-white/45 text-xs leading-relaxed">{cat.desc}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
