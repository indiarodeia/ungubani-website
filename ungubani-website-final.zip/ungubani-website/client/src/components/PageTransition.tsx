/* ============================================================
   UNGUBANI — Page Transition
   Slide-up navy overlay + glowing progress bar on route change
   ============================================================ */
import { createContext, useContext, useEffect, useRef, useState, useCallback, ReactNode } from "react";
import { useLocation } from "wouter";

type TransitionState = "idle" | "entering" | "leaving";

interface TransitionCtx {
  navigate: (to: string) => void;
}

const TransitionContext = createContext<TransitionCtx>({ navigate: () => {} });

export function useTransitionNavigate() {
  return useContext(TransitionContext).navigate;
}

export function PageTransitionProvider({ children }: { children: ReactNode }) {
  const [, setLocation] = useLocation();
  const [state, setState] = useState<TransitionState>("idle");
  const [barWidth, setBarWidth] = useState(0);
  const pendingRef = useRef<string | null>(null);

  const navigate = useCallback((to: string) => {
    if (state !== "idle") return;
    pendingRef.current = to;
    setState("entering");
    setBarWidth(40);
  }, [state]);

  useEffect(() => {
    if (state === "entering") {
      // Grow bar to 80% while overlay slides up
      const t1 = setTimeout(() => setBarWidth(80), 100);
      // After overlay covers screen, navigate and start leaving
      const t2 = setTimeout(() => {
        if (pendingRef.current) {
          setLocation(pendingRef.current);
          pendingRef.current = null;
          window.scrollTo({ top: 0, behavior: "instant" });
        }
        setBarWidth(100);
        setState("leaving");
      }, 440);
      return () => { clearTimeout(t1); clearTimeout(t2); };
    }
    if (state === "leaving") {
      // After overlay slides away, reset
      const t = setTimeout(() => {
        setState("idle");
        setBarWidth(0);
      }, 420);
      return () => clearTimeout(t);
    }
  }, [state, setLocation]);

  const overlayClass =
    state === "entering" ? "page-transition-overlay entering"
    : state === "leaving" ? "page-transition-overlay leaving"
    : "page-transition-overlay";

  return (
    <TransitionContext.Provider value={{ navigate }}>
      {/* Progress bar */}
      <div
        className="page-loader-bar"
        style={{
          width: barWidth > 0 ? `${barWidth}%` : "0%",
          opacity: barWidth > 0 && barWidth < 100 ? 1 : barWidth === 100 ? 0 : 0,
        }}
      />

      {/* Slide overlay */}
      <div className={overlayClass}>
        {/* Centered logo mark during transition */}
        <div
          className="absolute inset-0 flex items-center justify-center"
          style={{ opacity: state === "entering" ? 1 : 0, transition: "opacity 200ms ease" }}
        >
          <div className="flex flex-col items-center gap-3">
            <img
              src="/manus-storage/ungubanilogo-white_f048e63d.svg"
              alt="Ungubani"
              className="h-16 w-auto"
              style={{ opacity: 0.9 }}
            />
          </div>
        </div>
      </div>

      {children}
    </TransitionContext.Provider>
  );
}
