/* ============================================================
   UNGUBANI — Navbar
   Design: "Monolithic Authority" — transparent → solid navy on scroll
   Includes dark mode toggle + language toggle (PT/EN)
   ============================================================ */
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Menu, X, Sun, Moon } from "lucide-react";
import { useTransitionNavigate } from "./PageTransition";
import { useTheme } from "@/contexts/ThemeContext";
import { useLanguage } from "@/contexts/LanguageContext";

function ThemeToggle({ compact = false }: { compact?: boolean }) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  if (compact) {
    return (
      <button
        onClick={toggleTheme}
        aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
        className="flex items-center gap-2 text-white/70 hover:text-white transition-colors duration-200"
      >
        {isDark ? <Sun size={18} /> : <Moon size={18} />}
        <span className="text-[0.75rem] font-semibold tracking-wider uppercase">
          {isDark ? "Light" : "Dark"}
        </span>
      </button>
    );
  }

  return (
    <button
      onClick={toggleTheme}
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      title={isDark ? "Light mode" : "Dark mode"}
      className="relative flex items-center gap-2 group"
      style={{ outline: "none" }}
    >
      <Sun
        size={14}
        style={{
          color: isDark ? "oklch(0.63 0.11 240 / 0.5)" : "oklch(0.85 0.12 80)",
          transition: "color 300ms ease, transform 300ms ease",
          transform: isDark ? "scale(0.85)" : "scale(1)",
        }}
      />
      <div
        style={{
          width: "36px", height: "20px", borderRadius: "10px",
          background: isDark ? "oklch(0.50 0.14 255)" : "oklch(0.75 0.02 255)",
          position: "relative", transition: "background 300ms ease", flexShrink: 0,
        }}
      >
        <div
          style={{
            position: "absolute", top: "3px",
            left: isDark ? "19px" : "3px",
            width: "14px", height: "14px", borderRadius: "50%",
            background: "white",
            transition: "left 280ms cubic-bezier(0.23, 1, 0.32, 1)",
            boxShadow: "0 1px 4px rgba(0,0,0,0.3)",
          }}
        />
      </div>
      <Moon
        size={14}
        style={{
          color: isDark ? "oklch(0.85 0.08 240)" : "oklch(0.63 0.11 240 / 0.5)",
          transition: "color 300ms ease, transform 300ms ease",
          transform: isDark ? "scale(1)" : "scale(0.85)",
        }}
      />
    </button>
  );
}

function LangToggle({ compact = false }: { compact?: boolean }) {
  const { lang, toggleLang } = useLanguage();
  const isEN = lang === "en";

  if (compact) {
    return (
      <button
        onClick={toggleLang}
        aria-label={isEN ? "Mudar para Português" : "Switch to English"}
        className="flex items-center gap-2 text-white/70 hover:text-white transition-colors duration-200"
      >
        <span className="text-[0.75rem] font-semibold tracking-wider uppercase">
          {isEN ? "🇵🇹 PT" : "🇬🇧 EN"}
        </span>
      </button>
    );
  }

  return (
    <button
      onClick={toggleLang}
      aria-label={isEN ? "Mudar para Português" : "Switch to English"}
      title={isEN ? "Mudar para Português" : "Switch to English"}
      className="flex items-center gap-1.5 group"
      style={{ outline: "none" }}
    >
      {/* Inactive label */}
      <span
        style={{
          fontSize: "0.68rem",
          fontWeight: 700,
          letterSpacing: "0.08em",
          color: isEN ? "oklch(0.63 0.11 240)" : "oklch(0.75 0.02 255 / 0.55)",
          transition: "color 250ms ease",
        }}
      >
        PT
      </span>

      {/* Track */}
      <div
        style={{
          width: "32px", height: "18px", borderRadius: "9px",
          background: "oklch(0.50 0.14 255 / 0.55)",
          position: "relative", transition: "background 300ms ease", flexShrink: 0,
          border: "1px solid oklch(0.63 0.11 240 / 0.4)",
        }}
      >
        <div
          style={{
            position: "absolute", top: "2px",
            left: isEN ? "14px" : "2px",
            width: "12px", height: "12px", borderRadius: "50%",
            background: "white",
            transition: "left 280ms cubic-bezier(0.23, 1, 0.32, 1)",
            boxShadow: "0 1px 4px rgba(0,0,0,0.35)",
          }}
        />
      </div>

      {/* Active label */}
      <span
        style={{
          fontSize: "0.68rem",
          fontWeight: 700,
          letterSpacing: "0.08em",
          color: isEN ? "oklch(0.75 0.02 255 / 0.55)" : "oklch(0.63 0.11 240)",
          transition: "color 250ms ease",
        }}
      >
        EN
      </span>
    </button>
  );
}

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [location] = useLocation();
  const navigate = useTransitionNavigate();
  const { t } = useLanguage();

  const navLinks = [
    { href: "/", label: t("nav.home") },
    { href: "/quem-somos", label: t("nav.about") },
    { href: "/projetos", label: t("nav.projects") },
    { href: "/prime-infinity", label: t("nav.prime") },
    { href: "/contactos", label: t("nav.contact") },
  ];

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    document.body.style.overflow = "";
  }, [location]);

  const toggleMenu = () => {
    const next = !menuOpen;
    setMenuOpen(next);
    document.body.style.overflow = next ? "hidden" : "";
  };

  const handleNav = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    if (location === href) return;
    if (menuOpen) { setMenuOpen(false); document.body.style.overflow = ""; }
    navigate(href);
  };

  return (
    <>
      <nav
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
        style={{
          background: scrolled ? "oklch(0.22 0.06 255)" : "transparent",
          boxShadow: scrolled ? "0 2px 24px rgba(0,0,0,0.28)" : "none",
        }}
      >
        <div className="container flex items-center justify-between h-[76px]">
          {/* ── LOGO ──────────────────────────────────────────────────────
              LOGO PLACEHOLDER — quando tiver o logotipo real:
              1. Coloque o ficheiro em /home/ubuntu/webdev-static-assets/logo.svg
              2. Execute: manus-upload-file --webdev /home/ubuntu/webdev-static-assets/logo.svg
              3. Substitua o bloco abaixo por:
                 <img src="<URL retornado>" alt="Ungubani" className="h-10 w-auto" />
          ─────────────────────────────────────────────────────────────── */}
          <a href="/" onClick={(e) => handleNav(e, "/")} className="flex items-center flex-shrink-0">
            <img
              src="/manus-storage/ungubanilogo-white_f048e63d.svg"
              alt="Ungubani"
              className="h-12 w-auto transition-transform duration-200 hover:scale-105"
            />
          </a>

          {/* Desktop nav */}
          <ul className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={(e) => handleNav(e, link.href)}
                  className="nav-link relative text-white/80 hover:text-white transition-colors duration-200 text-[0.78rem] font-semibold tracking-[0.1em] uppercase"
                  style={location === link.href ? { color: "white" } : {}}
                >
                  {link.label}
                  {location === link.href && (
                    <span
                      className="absolute -bottom-1 left-0 right-0 h-[2px]"
                      style={{ background: "oklch(0.63 0.11 240)" }}
                    />
                  )}
                </a>
              </li>
            ))}
          </ul>

          {/* Controls: lang toggle + dark mode + CTA */}
          <div className="hidden lg:flex items-center gap-4">
            <LangToggle />
            {/* Thin separator */}
            <div style={{ width: "1px", height: "20px", background: "oklch(1 0 0 / 0.15)" }} />
            <ThemeToggle />
            <a
              href="/contactos"
              onClick={(e) => handleNav(e, "/contactos")}
              className="btn-solid btn-press px-5 py-2.5 text-[0.78rem] font-bold tracking-[0.08em] uppercase text-white rounded"
              style={{ background: "oklch(0.50 0.14 255)" }}
            >
              {t("nav.cta")}
            </a>
          </div>

          {/* Hamburger */}
          <button
            className="lg:hidden text-white p-1 transition-transform duration-200 hover:scale-110 active:scale-95"
            onClick={toggleMenu}
            aria-label="Menu"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div
        className="fixed inset-0 z-40 flex flex-col items-center justify-center gap-8 transition-all duration-300"
        style={{
          background: "oklch(0.22 0.06 255)",
          opacity: menuOpen ? 1 : 0,
          pointerEvents: menuOpen ? "auto" : "none",
        }}
      >
        {navLinks.map((link) => (
          <a
            key={link.href}
            href={link.href}
            onClick={(e) => handleNav(e, link.href)}
            className="text-white/80 hover:text-white transition-colors duration-200 font-black uppercase tracking-widest"
            style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "2rem", transition: "color 200ms ease, letter-spacing 200ms ease" }}
          >
            {link.label}
          </a>
        ))}

        <div className="flex items-center gap-6 mt-2">
          <LangToggle compact />
          <div style={{ width: "1px", height: "18px", background: "oklch(1 0 0 / 0.2)" }} />
          <ThemeToggle compact />
        </div>

        <a
          href="/contactos"
          onClick={(e) => handleNav(e, "/contactos")}
          className="btn-solid mt-2 px-8 py-3 text-white font-bold tracking-widest uppercase text-sm rounded"
          style={{ background: "oklch(0.50 0.14 255)" }}
        >
          {t("nav.cta")}
        </a>
      </div>
    </>
  );
}
