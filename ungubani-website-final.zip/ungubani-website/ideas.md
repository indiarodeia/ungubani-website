# Ungubani — Design Ideas

## Three Stylistic Approaches

### Approach A — "Structural Precision"
Inspired by Swiss International Typographic Style meets modern construction. Clean grid, strong typographic hierarchy, dark navy as the dominant tone with sharp white cuts.
**Probability: 0.04**

### Approach B — "Monolithic Authority" ← CHOSEN
Deep navy and steel blue palette, asymmetric editorial layout, architectural photography as full-bleed backgrounds, bold slab-serif display type contrasted with clean sans-serif body. Feels like a premium engineering firm — serious, confident, built to last.
**Probability: 0.07**

### Approach C — "Azorean Horizon"
Ocean-inspired palette (deep teal, slate, white), organic curves referencing the island landscape, warm stone textures. More poetic, less corporate.
**Probability: 0.03**

---

## Chosen Approach: "Monolithic Authority"

### Design Movement
Brutalist-Corporate — the weight and permanence of concrete expressed through bold typography, high-contrast color blocks, and uncompromising grid discipline.

### Core Principles
1. **Weight communicates trust** — heavy type, solid color blocks, no decorative fluff
2. **Asymmetric tension** — content never perfectly centered; offset grids create visual energy
3. **Photography as structure** — images are architectural elements, not decoration
4. **Restraint over excess** — every element earns its place

### Color Philosophy
- `--blue-dark: oklch(0.22 0.06 255)` — #0D2B4E equivalent: the anchor, used for navbars, dark sections, CTAs
- `--blue-mid: oklch(0.32 0.09 255)` — #1A4A7A equivalent: secondary blocks
- `--blue-accent: oklch(0.52 0.14 255)` — #1E6FB5 equivalent: interactive elements, links, highlights
- `--blue-sky: oklch(0.65 0.10 240)` — #4A9FD4 equivalent: labels, accents, hover states
- `--off-white: oklch(0.98 0.003 90)` — warm white for backgrounds
- `--gray-section: oklch(0.95 0.003 90)` — alternate section backgrounds
- Emotional intent: authority, stability, precision — the colors of deep ocean and clear sky

### Layout Paradigm
- Full-bleed hero with left-aligned content (never centered)
- Alternating left/right content-image splits
- Horizontal rule details and thin lines as structural elements
- Stats bar as a dark band breaking sections
- Project grid with hover-reveal overlays

### Signature Elements
1. **Thin horizontal rule + ALL-CAPS label** before every section heading
2. **Dark navy stats bar** with large counter numbers between sections
3. **Project cards** with full-bleed image and slide-up info overlay on hover

### Interaction Philosophy
Deliberate, confident interactions. No bouncy animations. Smooth 250ms ease-outs. Hover states reveal information rather than decorating.

### Animation
- Fade-up on scroll: `opacity 0→1, translateY 24px→0, duration 600ms, ease-out`
- Counter animation on stats bar entry
- Navbar: transparent → solid navy on scroll (200ms)
- Project card hover: image scale 1→1.04, overlay slide up (300ms ease-out)
- Button hover: translateY -1px, box-shadow intensify

### Typography System
- Display: `Barlow Condensed` 700/800 — bold, architectural, space-efficient
- Body: `Inter` 400/500 — clean, legible, professional
- Labels: `Inter` 600, letter-spacing 0.18em, all-caps, 0.72rem

### Brand Essence
**Ungubani: The builder that Azorean projects trust.** — Precise. Solid. Committed.

### Brand Voice
Headlines: direct, declarative, no fluff. "Construímos com propósito." not "Bem-vindo à Ungubani."
CTAs: action-first. "Fale Connosco" not "Clique aqui para saber mais."

### Wordmark & Logo
Placeholder: geometric "U" mark in a square tile with gradient from `--blue-accent` to `--blue-sky`. Will be replaced with real logo.

### Signature Brand Color
Deep Navy `oklch(0.22 0.06 255)` — the color of trust, depth, and permanence.
