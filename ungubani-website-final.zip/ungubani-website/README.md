# Ungubani — Website Institucional

Website institucional da **Ungubani — Construção Civil e Obras Públicas**, construído em React 19 + Tailwind CSS 4 + TypeScript.

---

## Abrir no VS Code

1. Descomprimir o ZIP (se necessário)
2. Abrir o VS Code → **File → Open Folder** → selecionar a pasta `ungubani-website/`
3. Instalar as extensões recomendadas:
   - **ESLint** — `dbaeumer.vscode-eslint`
   - **Prettier** — `esbenp.prettier-vscode`
   - **Tailwind CSS IntelliSense** — `bradlc.vscode-tailwindcss`
4. Instalar dependências no terminal integrado:
   ```bash
   pnpm install
   ```
5. Iniciar o servidor de desenvolvimento:
   ```bash
   pnpm dev
   ```
6. Abrir no browser: `http://localhost:3000`

---

## Estrutura do Projeto

```
ungubani-website/
├── client/
│   ├── public/
│   │   └── favicon.png              ← Favicon (substituir pelo definitivo)
│   ├── index.html                   ← Meta tags, título, fontes
│   └── src/
│       ├── components/
│       │   ├── Navbar.tsx           ← Barra de navegação (logo aqui)
│       │   ├── Footer.tsx           ← Rodapé (logo aqui)
│       │   ├── PageTransition.tsx   ← Overlay de transição (logo aqui)
│       │   ├── BackToTop.tsx        ← Botão "Voltar ao topo"
│       │   └── CookieBanner.tsx     ← Banner RGPD
│       ├── contexts/
│       │   ├── LanguageContext.tsx  ← Todas as traduções PT/EN
│       │   └── ThemeContext.tsx     ← Dark/Light mode
│       └── pages/
│           ├── Home.tsx             ← Página inicial
│           ├── QuemSomos.tsx        ← Quem Somos
│           ├── Projetos.tsx         ← Portfólio de projetos
│           ├── PrimeInfinity.tsx    ← Prime Infinity Residences
│           ├── Contactos.tsx        ← Contactos + formulário
│           └── PoliticaPrivacidade.tsx
```

---

## Substituir o Logotipo

O logotipo atual está em `/manus-storage/` (CDN). Para usar um novo logo:

### Opção A — Usar o logo no website publicado (Manus)
1. Fazer upload do novo ficheiro SVG/PNG
2. Substituir o URL nos 3 ficheiros abaixo

### Opção B — Usar localmente no VS Code
1. Colocar o ficheiro em `client/public/logo.svg`
2. Nos 3 ficheiros abaixo, substituir o `src` por `/logo.svg`

**Ficheiros a editar:**

| Ficheiro | Linha | O que substituir |
|----------|-------|-----------------|
| `client/src/components/Navbar.tsx` | ~213 | `src="/manus-storage/ungubanilogo-white_f048e63d.svg"` |
| `client/src/components/Footer.tsx` | ~41 | `src="/manus-storage/ungubanilogo-white_f048e63d.svg"` |
| `client/src/components/PageTransition.tsx` | ~84 | `src="/manus-storage/ungubanilogo-white_f048e63d.svg"` |

> **Nota:** O logo atual é uma variante com texto branco (para fundo escuro). Se o novo logo tiver texto escuro, adicione `style={{ filter: "brightness(0) invert(1)" }}` à tag `<img>`.

---

## Ativar o Formulário de Contacto (Formspree)

1. Criar conta gratuita em [formspree.io](https://formspree.io)
2. Criar um novo formulário e copiar o URL (ex: `https://formspree.io/f/xpwzgkla`)
3. Abrir `client/src/pages/Contactos.tsx`
4. Na linha 16, substituir:
   ```ts
   const FORMSPREE_ENDPOINT = "https://formspree.io/f/YOUR_FORM_ID";
   ```
   por:
   ```ts
   const FORMSPREE_ENDPOINT = "https://formspree.io/f/xpwzgkla"; // o seu URL real
   ```

---

## Alterar Conteúdos e Traduções

Todos os textos do website estão centralizados em:

```
client/src/contexts/LanguageContext.tsx
```

O ficheiro tem dois blocos: `pt` (Português) e `en` (Inglês). Cada chave corresponde a um texto no website. Basta editar os valores para atualizar o conteúdo em ambos os idiomas.

---

## Personalizar Cores

As cores principais estão em `client/src/index.css` nas variáveis CSS:

```css
:root {
  --background: oklch(1 0 0);          /* Fundo claro */
  --foreground: oklch(0.235 0.015 65); /* Texto escuro */
}
.dark {
  --background: oklch(0.141 0.005 285.823); /* Fundo escuro */
  --foreground: oklch(0.85 0.005 65);       /* Texto claro */
}
```

A cor azul principal da marca (`oklch(0.22 0.06 255)`) aparece diretamente nos componentes. Para alterar, faça uma pesquisa global por esse valor no VS Code (`Ctrl+Shift+H`) e substitua pelo novo.

---

## Comandos Úteis

```bash
pnpm dev          # Servidor de desenvolvimento
pnpm build        # Build de produção
pnpm preview      # Pré-visualizar build de produção
pnpm check        # Verificar erros TypeScript
pnpm format       # Formatar código com Prettier
```

---

## Tecnologias

- **React 19** + **TypeScript**
- **Tailwind CSS 4** + **shadcn/ui**
- **Wouter** — routing client-side
- **Framer Motion** — animações
- **Lucide React** — ícones
- **Formspree** — formulário de contacto (a configurar)

---

*Website desenvolvido para a Ungubani — Construção Civil e Obras Públicas, Açores, Portugal.*
